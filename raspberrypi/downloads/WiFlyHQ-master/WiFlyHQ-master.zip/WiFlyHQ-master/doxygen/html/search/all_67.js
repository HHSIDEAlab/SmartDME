var searchData=
[
  ['getfreememory',['getFreeMemory',['../class_wi_fly.html#a7988965adc898268d2eb52548f38c673',1,'WiFly']]],
  ['gethostbyname',['getHostByName',['../class_wi_fly.html#a2051052a072928e2ba37bd93cc3e3c20',1,'WiFly']]],
  ['gethostip',['getHostIP',['../class_wi_fly.html#a50a16eb3932125449e67643697c4fca8',1,'WiFly']]],
  ['gethostport',['getHostPort',['../class_wi_fly.html#add5ef6940763d8b4326c2e530bf81a73',1,'WiFly']]],
  ['getip',['getIP',['../class_wi_fly.html#a0071323aefaaf3b77ee6972cb166a118',1,'WiFly']]],
  ['getport',['getPort',['../class_wi_fly.html#abb057301f5856eb70ea4a5acbf04fc5a',1,'WiFly']]],
  ['getrate',['getRate',['../class_wi_fly.html#a1ebae0351aadda9ce5bb7adc8df3a5fd',1,'WiFly']]],
  ['gets',['gets',['../class_wi_fly.html#a762add6265dd90032287b8865a8a817f',1,'WiFly']]],
  ['gettxpower',['getTxPower',['../class_wi_fly.html#a173efa717ce2d8f7023b9b262e4615a6',1,'WiFly']]]
];
