var searchData=
[
  ['join',['join',['../class_wi_fly.html#a1a557580eae627aa0f0f6b111e908003',1,'WiFly::join(const char *ssid, uint16_t timeout=20000)'],['../class_wi_fly.html#a59fb81c1c9522534b8539dad374e7f69',1,'WiFly::join(uint16_t timeout=20000)'],['../class_wi_fly.html#a2e1a4ff4168128c98c4a7d71a280599f',1,'WiFly::join(const char *ssid, const char *password, bool dhcp=true, uint8_t mode=WIFLY_MODE_WPA, uint16_t timeout=20000)']]]
];
