var searchData=
[
  ['write',['write',['../class_wi_fly.html#a5a20b7e512452efe430e67fc97f8a190',1,'WiFly']]]
];
