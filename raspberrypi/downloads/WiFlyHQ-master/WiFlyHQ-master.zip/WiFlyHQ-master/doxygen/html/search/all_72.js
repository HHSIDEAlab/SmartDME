var searchData=
[
  ['read',['read',['../class_wi_fly.html#a5dbfebf6ebdce4276f8b0d5cacf98317',1,'WiFly']]],
  ['reboot',['reboot',['../class_wi_fly.html#aa64722671a775b2cbbbb031395397505',1,'WiFly']]]
];
