var searchData=
[
  ['open',['open',['../class_wi_fly.html#a06969fe6f0008d0fc9e8b927e3cd2077',1,'WiFly::open(const char *addr, int port=80, boolean block=true)'],['../class_wi_fly.html#aa77120d8605228294003978775f6f7fa',1,'WiFly::open(IPAddress addr, int port=80, boolean block=true)']]],
  ['opencomplete',['openComplete',['../class_wi_fly.html#a457a8823a24ce0199787249971c58090',1,'WiFly']]]
];
