var searchData=
[
  ['close',['close',['../class_wi_fly.html#adf4138137065fd78de83a18825f47795',1,'WiFly']]],
  ['createadhocnetwork',['createAdhocNetwork',['../class_wi_fly.html#ac84cdf8e1dd3c544bb935548af9d114e',1,'WiFly']]]
];
